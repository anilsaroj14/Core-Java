package TESTNG_TESTS;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import BASE_CLASSES.ShoppingMethods;

public class NewTest{
	
	ShoppingMethods sm;
	WebDriver dr;
	String str;
	String xp;
	String price1, price2;
	Logger log;

@Test
  public void f() {
//	System.setProperty("webdriver.gecko.driver", "geckodriver.exe");
//	dr = new FirefoxDriver();
//	
	System.setProperty("webdriver.chrome.driver", "chromedriver_v75.exe");
	dr = new ChromeDriver();
	
//	System.setProperty("webdriver.ie.driver", "IEDriverServer.exe");
//	dr = new InternetExplorerDriver();
	
	dr.get("http://automationpractice.com/index.php");
	sm = new ShoppingMethods(dr);
	sm.login();
	System.out.println("Login Successfully");
	log=Logger.getLogger("devpinoyLogger");
	log.info("Login Successfully");
}
	

@Test
public void f1() {
	
	sm = new ShoppingMethods(dr);
	xp = "//*[@class='account']";
	str = sm.verifyName(xp);
//	SoftAssert sa = new SoftAssert();
//	sa.assertEquals(str, "abc def");
	Assert.assertEquals(str, "abc def");
	System.out.println("Username Verified");
	log=Logger.getLogger("devpinoyLogger");
	log.info("Username Verified");

}

//@Test
//public void f2() {
//	
//	SoftAssert sa = new SoftAssert();
//	sa.assertEquals(str, "abcdef");
//	System.out.println("Username is wrong");
//
//}

@Test
public void f3() {
	
	sm = new ShoppingMethods(dr);
	sm.addToCart();
	System.out.println("Products added to the cart");
	log=Logger.getLogger("devpinoyLogger");
	log.info("Products added to the cart");

}

@Test
public void f4() {
	
	sm = new ShoppingMethods(dr);
	xp = "/html/body/div/div[2]/div/div[3]/div/div[2]/table/tbody/tr[1]/td[2]/p/a";
	str = sm.verifyName(xp);
	SoftAssert sa = new SoftAssert();
	sa.assertEquals(str, "Printed Dress");
	System.out.println("Name of Product 1 is correct");
	log=Logger.getLogger("devpinoyLogger");
	log.info("Name of Product 1 is correct");

}

@Test
public void f5() {
	
	sm = new ShoppingMethods(dr);
	xp = "/html/body/div/div[2]/div/div[3]/div/div[2]/table/tbody/tr[2]/td[2]/p/a";
	str = sm.verifyName(xp);
	SoftAssert sa = new SoftAssert();
	sa.assertEquals(str, "Fade Short Sleeve T-Shirt");
	System.out.println("Name of Product 2 is correct");
	log=Logger.getLogger("devpinoyLogger");
	log.info("Name of Product 2 is correct");

}

@Test
public void f6() {
	
	sm = new ShoppingMethods(dr);
	xp = "/html/body/div/div[2]/div/div[3]/div/div[2]/table/tbody/tr[1]/td[4]/span/span";
	price1 = sm.unitPrice(xp);
	SoftAssert sa = new SoftAssert();
	sa.assertEquals(str, "26.00");
	System.out.println("Price of Product 1 is correct");
	log=Logger.getLogger("devpinoyLogger");
	log.info("Price of Product 1 is correct");

}
  
@Test
public void f7() {
	
	sm = new ShoppingMethods(dr);
	xp = "/html/body/div/div[2]/div/div[3]/div/div[2]/table/tbody/tr[2]/td[4]/span/span";
	price2 = sm.unitPrice(xp);
	SoftAssert sa = new SoftAssert();
	sa.assertEquals(str, "16.51");
	System.out.println("Price of Product 1 is correct");
	log=Logger.getLogger("devpinoyLogger");
	log.info("Price of Product 1 is correct");

}

@Test
public void f8() {
	
	sm = new ShoppingMethods(dr);
	xp = "//*[@id=\"total_price\"]";
	str = sm.totalPrice(xp);
	double total = (Double.parseDouble(price1))*1 + (Double.parseDouble(price2))*2 + 2 ;
	String totalPrice = Double.toString(total);
	SoftAssert sa = new SoftAssert();
	sa.assertEquals(str, totalPrice);
	System.out.println("Total price is correct");
	log=Logger.getLogger("devpinoyLogger");
	log.info("Total price is correct");

}

}
