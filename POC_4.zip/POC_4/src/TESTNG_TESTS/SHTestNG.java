package TESTNG_TESTS;

import java.net.MalformedURLException;
import java.net.URL;

import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class SHTestNG {
	
	WebDriver dr;
	String baseURL, nodeURL;
	
	@BeforeClass
	  public void setup() throws MalformedURLException 
	  {
		
		  nodeURL = "http://172.16.70.157:5566/wd/hub";
		  DesiredCapabilities cap = DesiredCapabilities.firefox();
		  cap.setBrowserName("firefox");
		  cap.setPlatform(Platform.WINDOWS);
		  dr = new RemoteWebDriver(new URL(nodeURL), cap);
		  
	  }
	  
	 @Test
	  public void test1()
	  {
		  dr.get("https://www.facebook.com");
	  }
}
