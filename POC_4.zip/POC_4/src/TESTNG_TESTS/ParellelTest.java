package TESTNG_TESTS;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

import BASE_CLASSES.ShoppingMethods;

public class ParellelTest {
	
	ShoppingMethods sm;
	WebDriver dr;
	String str;
	String xp;
	String price1, price2;
	Logger log;
	
  @Test
  public void f() {
	  
	  	System.setProperty("webdriver.chrome.driver", "chromedriver_v75.exe");
	  	dr = new ChromeDriver();
	  
	  	dr.get("http://automationpractice.com/index.php");
	  	sm = new ShoppingMethods(dr);
		sm.login();
		System.out.println("Login Successfully");
		log=Logger.getLogger("devpinoyLogger");
		log.info("Login Successfully");
		
		
		

  }
}
